x = int(input())
if x % 4 == 0:
    print('Год весокосный')
else:
    print('Год не весокосный')
